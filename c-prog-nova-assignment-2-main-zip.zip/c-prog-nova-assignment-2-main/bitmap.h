#include<stdio.h>
#include<string.h>

char* rmvExpAlpha(char *str);
const char* sortStr(char *lowerCase);
unsigned int revDigit(unsigned int num);
unsigned int biValue(unsigned int num);
