
#include<stdio.h>
#include<string.h> 


int arrLength(const char* str);
int repCharaCheck(const char* str1);
int checkAnyIndex(const char* str, int indexPosition);
char checkMidChara( const char* str);
