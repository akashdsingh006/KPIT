# include <stdio.h>
# include <string.h>


int EvenNoCount(unsigned int arr[],unsigned int arrLength);
int StrCompare(const char *str, const char *str1);
int NumCount(const char *str);
char ToggleCharCase(const char *str, unsigned int indexposition);
