#include<stdio.h>
#include<math.h>
#include<string.h>


int Sequence(unsigned int Num);
int NivenNumber(unsigned int Num);
int Find3rdSmallestNumber(unsigned int arrVal[], unsigned int arrSize);
int countNumbersExceptFive(int start, int end);
long sumOfTwoLargestNumbers(int length , const int numbers[]);
