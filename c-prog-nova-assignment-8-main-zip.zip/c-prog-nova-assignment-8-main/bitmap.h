#ifndef BITMAP_H
#define BITMAP_H

extern char number[10];
//struct declaration for Data values
struct Data{
    float angle;
    int degree;
};

//function declaration
int factorial(int x);
float approximateTaylorSeries(struct Data d1);

#endif
